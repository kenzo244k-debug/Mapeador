# Mapper Pro v0.3.0 — Android nativo

## Incluído nesta revisão
- Interface Android com quatro mapeamentos de teclas físicas para posições X/Y percentuais.
- Persistência local das teclas e coordenadas.
- HUD flutuante arrastável.
- Modo Both: tenta executar o toque por Shizuku autorizado e usa Accessibility como alternativa quando Shizuku não está disponível ou falha.
- Fluxo de solicitação de autorização Shizuku e indicação de estado.
- Workflow GitHub Actions para compilar o APK debug e publicar o arquivo como artefato da execução.

## Requisitos
- Android 8.0 ou superior (minSdk 26).
- Android SDK 35 e Gradle 8.9 para compilação.
- Para o backend Shizuku: aplicativo Shizuku instalado, iniciado pelo próprio usuário e autorizado para Mapper Pro. Em Android 11+, o Shizuku pode ser iniciado usando Depuração sem fio. A disponibilidade do comando `input tap` depende das permissões efetivas do servidor.
- Para alternativa: serviço Mapper Pro habilitado em Configurações > Acessibilidade.
- Para HUD: permissão de sobreposição concedida manualmente.

## Compilar sem instalar ferramentas no telefone
1. Envie o conteúdo desta pasta para um repositório GitHub seu, mantendo `MapperPro/` na raiz.
2. Abra a aba Actions e execute **Build Mapper Pro APK** (ou faça push na branch main/master).
3. Quando a execução terminar, abra a execução e baixe o artefato **MapperPro-debug-apk**.
4. Extraia `app-debug.apk` e instale no Android. O Android pode pedir autorização para instalar apps dessa origem.

O workflow gera APK de depuração, não um APK assinado para publicação na Play Store.

## Limitações honestas desta versão
- O mapeamento é de teclas físicas para toques pontuais; não há controle contínuo de câmera/mira por movimento relativo do mouse.
- Não há analógico WASD contínuo, multitouch simultâneo, macros ou perfis por jogo.
- Shizuku `newProcess` é uma API legada/depreciada no projeto oficial e deverá ser substituída por UserService antes de uma versão de produção. O modo Both foi integrado como tentativa Shizuku com fallback de Acessibilidade, mas precisa ser validado em aparelho real.
- Este ambiente de trabalho não contém Android SDK nem Gradle; por isso não foi possível executar a compilação ou validar a instalação aqui.

## Privacidade e permissões
O app não pede login nem envia configurações para um servidor. As coordenadas e teclas ficam no armazenamento local do aplicativo. A permissão de Acessibilidade pode permitir observar eventos de teclas e executar gestos; conceda-a somente se compreender esse uso.
