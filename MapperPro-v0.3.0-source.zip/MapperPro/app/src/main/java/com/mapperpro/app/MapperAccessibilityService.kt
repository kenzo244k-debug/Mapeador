package com.mapperpro.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.pm.PackageManager
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import rikka.shizuku.Shizuku
import kotlin.math.roundToInt

class MapperAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("mapper_profiles", MODE_PRIVATE) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        val slot = (0..3).firstOrNull {
            prefs.getInt("key$it", 0) == event.keyCode && event.keyCode != 0
        } ?: return false

        val dm = resources.displayMetrics
        val x = ((prefs.getFloat("x$slot", 50f).coerceIn(0f, 100f) / 100f) * dm.widthPixels).roundToInt()
        val y = ((prefs.getFloat("y$slot", 50f).coerceIn(0f, 100f) / 100f) * dm.heightPixels).roundToInt()

        // Both mode: prefer Shizuku when it is running and authorized; fall back to
        // Android Accessibility gestures if Shizuku is unavailable or the command fails.
        if (prefs.getBoolean("both_mode", true) && canUseShizuku()) {
            Thread {
                val completed = runCatching {
                    Shizuku.newProcess(arrayOf("input", "tap", x.toString(), y.toString()), null, null).waitFor() == 0
                }.getOrDefault(false)
                if (!completed) Handler(Looper.getMainLooper()).post { runAccessibilityTap(x, y) }
            }.start()
        } else {
            runAccessibilityTap(x, y)
        }
        return true
    }

    private fun canUseShizuku(): Boolean = runCatching {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    private fun runAccessibilityTap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
