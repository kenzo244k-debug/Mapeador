package com.mapperpro.app

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("mapper_profiles", Context.MODE_PRIVATE) }
    private val keyButtons = mutableListOf<Button>()
    private val xFields = mutableListOf<EditText>()
    private val yFields = mutableListOf<EditText>()
    private var captureSlot = -1
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST_CODE) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            if (granted) prefs.edit().putBoolean("both_mode", true).apply()
            val message = if (granted) "Shizuku autorizado. Modo Both ativado." else "Permissão Shizuku não concedida"
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        window.statusBarColor = Color.rgb(16, 24, 40)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 24); setBackgroundColor(Color.rgb(245,247,251)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply { text = "MAPPER PRO"; textSize = 28f; setTextColor(Color.rgb(16,24,40)); typeface = Typeface.DEFAULT_BOLD })
        content.addView(TextView(this).apply { text = "v0.3.0  •  Mapeamento básico de teclado para toque"; textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0,4,0,18) })
        content.addView(TextView(this).apply { text = "Configure até quatro teclas. Cada tecla executa um toque na posição percentual da tela."; textSize = 15f; setTextColor(Color.BLACK); setPadding(0,0,0,12) })

        repeat(4) { i ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,12,14,14); setBackgroundColor(Color.WHITE) }
            card.addView(TextView(this).apply { text = "MAPEAMENTO ${i+1}"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(23,105,224)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val kb = Button(this).apply { text = keyLabel(i); setOnClickListener { captureSlot = i; text = "Pressione uma tecla..."; Toast.makeText(this@MainActivity,"Agora pressione a tecla física desejada",Toast.LENGTH_SHORT).show() } }
            keyButtons.add(kb)
            row.addView(kb, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f))
            val xf = EditText(this).apply { hint = "X %"; inputType =  numberInput(); setText(prefs.getFloat("x$i", 50f).toInt().toString()) }
            val yf = EditText(this).apply { hint = "Y %"; inputType = numberInput(); setText(prefs.getFloat("y$i", 50f).toInt().toString()) }
            xFields.add(xf); yFields.add(yf)
            row.addView(xf, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, .55f))
            row.addView(yf, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, .55f))
            card.addView(row)
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); params.bottomMargin = 12
            content.addView(card, params)
        }
        content.addView(actionButton("SALVAR MAPEAMENTOS") { saveMaps() })
        content.addView(actionButton("ATIVAR MODO BOTH (SHIZUKU + ACESSIBILIDADE)") { requestShizukuPermission() })
        content.addView(TextView(this).apply {
            text = shizukuStatus()
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 4, 0, 10)
        })
        content.addView(actionButton("ATIVAR SERVIÇO DE ACESSIBILIDADE") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        content.addView(actionButton("PERMITIR SOBREPOSIÇÃO") { if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else Toast.makeText(this,"Permissão já concedida",Toast.LENGTH_SHORT).show() })
        content.addView(actionButton("MOSTRAR / OCULTAR HUD") { toggleOverlay() })
        content.addView(TextView(this).apply { text = "Como testar: conecte um teclado, escolha uma tecla em cada cartão, informe X e Y em porcentagem (0 a 100), salve e habilite o serviço. X=0 é a esquerda; Y=0 é o topo. Teste primeiro em um app comum."; textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0,16,0,8) })
        content.addView(TextView(this).apply { text = "Limites desta versão: mapeia teclas para toques simples fixos. Ainda não faz mira FPS por movimento do mouse, analógico WASD contínuo, multitouch simultâneo nem macros. O Android executa gestos sintéticos por Acessibilidade; isso é necessário para transformar uma tecla em toque."; textSize = 13f; setTextColor(Color.rgb(140,65,0)); setPadding(0,8,0,12) })
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Inicie o Shizuku primeiro", Toast.LENGTH_LONG).show()
                return
            }
            if (Shizuku.isPreV11) {
                Toast.makeText(this, "Atualize o Shizuku para uma versão compatível", Toast.LENGTH_LONG).show()
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                prefs.edit().putBoolean("both_mode", true).apply()
                Toast.makeText(this, "Modo Both pronto. Mantenha Acessibilidade ativada como alternativa.", Toast.LENGTH_LONG).show()
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
            }
        } catch (_: Throwable) {
            Toast.makeText(this, "Não foi possível comunicar com Shizuku", Toast.LENGTH_LONG).show()
        }
    }

    private fun shizukuStatus(): String = try {
        when {
            !Shizuku.pingBinder() -> "Shizuku: não conectado. Acessibilidade continua disponível."
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "Shizuku: autorizado • modo Both disponível"
            else -> "Shizuku: conectado, aguardando autorização"
        }
    } catch (_: Throwable) {
        "Shizuku: indisponível • Acessibilidade como alternativa"
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        super.onDestroy()
    }

    private fun numberInput() = android.text.InputType.TYPE_CLASS_NUMBER
    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun keyLabel(i: Int): String {
        val code = prefs.getInt("key$i", 0)
        return if (code == 0) "DEFINIR TECLA" else "TECLA: ${KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")}"
    }
    private fun saveMaps() {
        val edit = prefs.edit()
        for (i in 0..3) {
            val x = xFields[i].text.toString().toFloatOrNull()?.coerceIn(0f,100f) ?: 50f
            val y = yFields[i].text.toString().toFloatOrNull()?.coerceIn(0f,100f) ?: 50f
            edit.putFloat("x$i",x).putFloat("y$i",y)
        }
        edit.apply(); Toast.makeText(this,"Mapeamentos salvos",Toast.LENGTH_SHORT).show()
    }
    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"Conceda primeiro a permissão de sobreposição",Toast.LENGTH_LONG).show(); return }
        val intent = Intent(this, OverlayService::class.java)
        if (OverlayService.running) stopService(intent) else startService(intent)
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (captureSlot >= 0 && event?.repeatCount == 0) {
            prefs.edit().putInt("key$captureSlot", keyCode).apply()
            keyButtons[captureSlot].text = "TECLA: ${KeyEvent.keyCodeToString(keyCode).removePrefix("KEYCODE_")}"
            captureSlot = -1
            return true
        }
        return super.onKeyDown(keyCode,event)
    }
    companion object { private const val SHIZUKU_REQUEST_CODE = 4102 }
}
