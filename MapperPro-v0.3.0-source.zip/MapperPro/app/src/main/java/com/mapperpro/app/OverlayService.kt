package com.mapperpro.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var badge: TextView? = null
    private lateinit var params: WindowManager.LayoutParams
    private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
    override fun onCreate() {
        super.onCreate(); running = true
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        badge = TextView(this).apply {
            text = "MP"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(23,105,224)); gravity = Gravity.CENTER; setPadding(18,12,18,12)
            setOnTouchListener { _, e ->
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; true }
                    MotionEvent.ACTION_MOVE -> { params.x=startX+(e.rawX-downX).toInt(); params.y=startY+(e.rawY-downY).toInt(); wm.updateViewLayout(this,params); true }
                    MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-downX)<8 && kotlin.math.abs(e.rawY-downY)<8) { val i=Intent(this@OverlayService,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }; true }
                    else -> false
                }
            }
        }
        params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=24; y=180 }
        wm.addView(badge,params)
    }
    override fun onDestroy() { running=false; badge?.let { wm.removeView(it) }; badge=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { @Volatile var running = false }
}
